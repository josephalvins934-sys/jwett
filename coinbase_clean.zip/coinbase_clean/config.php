<?php
$api = "your Bot Token";
$chatid = "your chat token";
$send = "youremail.com";
?>