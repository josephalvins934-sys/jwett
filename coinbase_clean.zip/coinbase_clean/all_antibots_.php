<?php

$_file_='d1'.basename(__FILE__). date("m");
echo $_file_;
